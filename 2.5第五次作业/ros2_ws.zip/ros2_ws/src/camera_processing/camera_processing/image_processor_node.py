#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class ImageProcessorNode(Node):
    def __init__(self):
        super().__init__('image_processor_node')
        self.subscription = self.create_subscription(
            Image,
            'camera/image',
            self.listener_callback,
            10)
        self.bridge = CvBridge()
        self.get_logger().info("图像处理节点已启动，等待图像数据...")

    def listener_callback(self, msg):
        try:
            # 将ROS图像消息转换为OpenCV图像
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            
            # 在这里添加您的图像处理代码
            # 示例：转换为灰度图
            gray_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
            
            # 显示原始图像和处理后的图像
            cv2.imshow('Original Image', cv_image)
            cv2.imshow('Processed Image (Grayscale)', gray_image)
            cv2.waitKey(1)  # 必要的一毫秒延迟
            
            self.get_logger().info('处理图像帧', throttle_duration_sec=1.0)  # 每秒只记录一次
            
        except Exception as e:
            self.get_logger().error(f"处理图像时出错: {str(e)}")

def main(args=None):
    rclpy.init(args=args)
    image_processor_node = ImageProcessorNode()
    try:
        rclpy.spin(image_processor_node)
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows()
        image_processor_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
